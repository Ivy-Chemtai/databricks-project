# Databricks notebook source
# MAGIC %md
# MAGIC ##Init

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.types import StringType
from pyspark.sql.functions import trim, col

# COMMAND ----------

# MAGIC %md
# MAGIC ##Reading from the silver layer
# MAGIC

# COMMAND ----------

df=spark.table("workspace.silver.crm_products")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Data Transformation and Logic

# COMMAND ----------

df = spark.sql("""
SELECT
    ROW_NUMBER() OVER (ORDER BY pn.start_date, pn.product_number) AS product_key,
    pn.product_id,
    pn.product_number,
    pn.product_name,
    pc.category_id,
    pc.category,
    pc.subcategory,
    pc.maintenance_flag,
    pn.product_line,
    pn.start_date
FROM silver.crm_products pn
LEFT JOIN silver.erp_product_category pc
    ON pn.product_line = pc.category
""")



# COMMAND ----------

# MAGIC %md
# MAGIC ##Writing to the Gold layer

# COMMAND ----------

(
    df.write
        .format("delta")
        .mode("overwrite")
        .saveAsTable("gold.dim_products")
)