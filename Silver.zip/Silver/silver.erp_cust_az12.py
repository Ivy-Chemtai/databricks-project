# Databricks notebook source
# MAGIC %md
# MAGIC ##Init

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.types import StringType
from pyspark.sql.functions import trim, col

# COMMAND ----------

# MAGIC %md
# MAGIC ##Reading from the Bronze layer
# MAGIC

# COMMAND ----------

df=spark.table("workspace.bronze.erp_cust_az12")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ###Triming

# COMMAND ----------

for field in df.schema.fields:
    if isinstance(field.dataType, StringType):
        df = df.withColumn(field.name, trim(col(field.name)))

# COMMAND ----------

# MAGIC %md
# MAGIC ###Customer id clean up

# COMMAND ----------

df = df.withColumn(
    "cid",
    F.when(col("cid").startswith("NAS"),
           F.substring(col("cid"), 4, F.length(col("cid"))))
     .otherwise(col("cid"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Birthdate Validation
# MAGIC

# COMMAND ----------

df = df.withColumn(
    "bdate",
    F.when(col("bdate") > F.current_date(), None)
     .otherwise(col("bdate"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Gender Normalization

# COMMAND ----------

df = df.withColumn(
    "gen",
    F.when(F.upper(col("gen")).isin("F", "FEMALE"), "Female")
     .when(F.upper(col("gen")).isin("M", "MALE"), "Male")
     .otherwise("n/a")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Columns Renaming

# COMMAND ----------

RENAME_MAP = {
    "cid": "customer_number",
    "bdate": "birth_date",
    "gen": "gender"
}
for old_name, new_name in RENAME_MAP.items():
    df = df.withColumnRenamed(old_name, new_name)

# COMMAND ----------

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Writing to the silver layer

# COMMAND ----------

df.write.mode("overwrite").format("delta").saveAsTable("workspace.silver.erp_customers")