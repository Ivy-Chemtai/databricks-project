# Databricks notebook source
# MAGIC %md
# MAGIC ##Init

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.types import StringType
from pyspark.sql.functions import trim, col

# COMMAND ----------

# MAGIC %md
# MAGIC ##Reading from silver layer
# MAGIC

# COMMAND ----------

df=spark.table("workspace.silver.crm_customers")
df=spark.table("workspace.silver.erp_customer_location")
df=spark.table("workspace.silver.erp_customers")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Business Transformations and Modelling

# COMMAND ----------

# DBTITLE 1,Business Transformations and Modelling
# MAGIC %sql
# MAGIC SELECT
# MAGIC     ROW_NUMBER() OVER (ORDER BY ci.customer_id) AS customer_key,
# MAGIC     ci.customer_id,
# MAGIC     ca.customer_number,
# MAGIC     ci.customer_firstname AS first_name,
# MAGIC     ci.customer_lastname AS last_name,
# MAGIC     la.country,
# MAGIC     ci.customer_marital_status AS marital_status,
# MAGIC     CASE
# MAGIC         WHEN ci.customer_gender <> 'n/a' THEN ci.customer_gender
# MAGIC         ELSE COALESCE(ca.gender, 'n/a')
# MAGIC     END AS gender,
# MAGIC     ca.birth_date AS birthdate,
# MAGIC     ci.customer_create_date AS create_date
# MAGIC FROM workspace.silver.crm_customers ci
# MAGIC LEFT JOIN workspace.silver.erp_customers ca
# MAGIC     ON ci.customer_key = ca.customer_number
# MAGIC LEFT JOIN workspace.silver.erp_customer_location la
# MAGIC     ON ca.customer_number = la.customer_number;

# COMMAND ----------

df = spark.sql("""
SELECT
    ROW_NUMBER() OVER (ORDER BY ci.customer_id) AS customer_key,
    ci.customer_id,
    ca.customer_number,
    ci.customer_firstname AS first_name,
    ci.customer_lastname AS last_name,
    la.country,
    ci.customer_marital_status AS marital_status,
    CASE
        WHEN ci.customer_gender <> 'n/a' THEN ci.customer_gender
        ELSE COALESCE(ca.gender, 'n/a')
    END AS gender,
    ca.birth_date AS birthdate,
    ci.customer_create_date AS create_date
FROM workspace.silver.crm_customers ci
LEFT JOIN workspace.silver.erp_customers ca
    ON ci.customer_key = ca.customer_number
LEFT JOIN workspace.silver.erp_customer_location la
    ON ca.customer_number = la.customer_number
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Writing to gold layer

# COMMAND ----------

(
    df.write
      .format("delta")
      .mode("overwrite")
      .saveAsTable("gold.dim_customers")
)

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

