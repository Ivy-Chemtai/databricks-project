# Databricks notebook source
# MAGIC %md
# MAGIC ##Init

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.types import StringType, DateType
from pyspark.sql.functions import col, trim
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ##Reading from the bronze layer

# COMMAND ----------

df=spark.table("workspace.bronze.crm_prd_info")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Data transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ###Removing Nulls

# COMMAND ----------

df = df.withColumn("prd_cost", F.coalesce(col("prd_cost"), F.lit(0)))


# COMMAND ----------

# MAGIC %md
# MAGIC ###Trimming
# MAGIC

# COMMAND ----------

for field in df.schema.fields:
    if isinstance(field.dataType, StringType):
        df = df.withColumn(field.name, trim(col(field.name)))

# COMMAND ----------

# MAGIC %md
# MAGIC ###date casting

# COMMAND ----------

f = df.withColumn("prd_start_dt", col("prd_start_dt").cast(DateType()))


# COMMAND ----------

# MAGIC %md
# MAGIC ###Columns Renaming
# MAGIC

# COMMAND ----------

RENAME_MAP = {
    "prd_id": "product_id",
    "cat_id": "category_id",
    "prd_key": "product_number",
    "prd_nm": "product_name",
    "prd_cost": "product_cost",
    "prd_line": "product_line",
    "prd_start_dt": "start_date",
    "prd_end_dt": "end_date"
}
for old_name, new_name in RENAME_MAP.items():
    df = df.withColumnRenamed(old_name, new_name)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Normalization
# MAGIC

# COMMAND ----------

df = df.withColumn(
    "product_line",
    F.when(col("product_line").isNull(), "n/a")
     .when(F.upper(col("product_line")) == "M", "Mountain")
     .when(F.upper(col("product_line")) == "R", "Road")
     .when(F.upper(col("product_line")) == "S", "Other Sales")
     .when(F.upper(col("product_line")) == "T", "Touring")
     .otherwise("n/a")
)

# COMMAND ----------

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ###Writing to Silver layer

# COMMAND ----------

df.write.mode("overwrite").format("delta").saveAsTable("workspace.silver.crm_products")