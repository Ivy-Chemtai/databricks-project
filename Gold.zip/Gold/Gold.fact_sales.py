# Databricks notebook source
# MAGIC %md
# MAGIC ##Init

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.types import StringType
from pyspark.sql.functions import trim, col

# COMMAND ----------

# MAGIC %md
# MAGIC ##Reading from the silver layer

# COMMAND ----------

df=spark.table("workspace.silver.crm_sales")



# COMMAND ----------

# MAGIC %md
# MAGIC ##Data Transformation

# COMMAND ----------

df = spark.sql("""
SELECT
    sd.order_number,
    pr.product_key,
    cu.customer_key,
    sd.order_date,
    sd.ship_date,
    sd.due_date,
    sd.sales_amount,
    sd.quantity,
    sd.price
FROM silver.crm_sales sd
LEFT JOIN gold.dim_products pr
    ON sd.product_number = pr.product_number
LEFT JOIN gold.dim_customers cu
    ON sd.customer_id = cu.customer_id;
""")

# COMMAND ----------

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Writing to the gold layer

# COMMAND ----------

(
    df.write
    .mode("overwrite")
    .format("delta")
    .saveAsTable("gold.fact_sales")
)