# Databricks notebook source
# MAGIC %md
# MAGIC ##Init
# MAGIC

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.types import StringType, DateType
from pyspark.sql.functions import trim, col

# COMMAND ----------

# MAGIC %md
# MAGIC ##Reading from bronze

# COMMAND ----------

df=spark.table("workspace.bronze.erp_loc_a101")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Data Transformation

# COMMAND ----------

# MAGIC %md
# MAGIC ###Triming

# COMMAND ----------

for field in df.schema.fields:
    if isinstance(field.dataType, StringType):
        df = df.withColumn(field.name, trim(col(field.name)))

# COMMAND ----------

# MAGIC %md
# MAGIC ###Customer ID clean up

# COMMAND ----------

df = df.withColumn("cid", F.regexp_replace(col("cid"), "-", ""))

# COMMAND ----------

# MAGIC %md
# MAGIC ###Normalization

# COMMAND ----------

df = df.withColumn(
    "cntry",
    F.when(col("cntry") == "DE", "Germany")
     .when(col("cntry").isin("US", "USA"), "United States")
     .when((col("cntry") == "") | col("cntry").isNull(), "n/a")
     .otherwise(col("cntry"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Columns Renaming

# COMMAND ----------

RENAME_MAP = {
    "cid": "customer_number",
    "cntry": "country"
}
for old_name, new_name in RENAME_MAP.items():
    df = df.withColumnRenamed(old_name, new_name)

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Writing to the silver layer

# COMMAND ----------

df.write.mode("overwrite").format("delta").saveAsTable("workspace.silver.erp_customer_location")